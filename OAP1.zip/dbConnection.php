<?php
//all the variables defined here are accessible in all the files that include this one
$con= new mysqli('sql302.epizy.com','epiz_28230466','WKRVaIalELnIP','epiz_28230466_fproject')or die("Could not connect to mysql".mysqli_error($con));

?>